package com.practica.sistema_webclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaWebclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaWebclientApplication.class, args);
	}

}
