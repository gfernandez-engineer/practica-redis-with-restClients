package com.practica.sistema_webclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaWebclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
